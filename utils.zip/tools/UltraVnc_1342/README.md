## Description

The files in this directory are licensed under GNU/GPL and distributed in <https://www.uvnc.com/component/jdownloads/summary/415-ultravnc-1-3-42-bin-zip.html>.

The source code is in <https://github.com/ultravnc/UltraVNC>.
